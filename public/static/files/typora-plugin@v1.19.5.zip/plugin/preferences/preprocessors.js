module.exports = (plugin) => {
  const { utils, i18n } = plugin
  const _disableControl = (field, tooltip = i18n._t("settings", "$tooltip.lowVersion")) => {
    field.disabled = true
    field.tooltip = tooltip
  }
  const _enableControl = (field, deleteTooltip = false) => {
    field.disabled = false
    if (deleteTooltip) delete field.tooltip
  }
  const _disableSwitch = (field, data, tooltip) => {
    _disableControl(field, tooltip)
    data[field.key] = false
  }
  const _disableOptions = (field, ...options) => field.disabledOptions = options
  return {
    global: {
      pluginVersion: (field, data) => {
        if (!data[field.key]) {
          let version = "Unknown"
          try {
            version = require("../VERSION.json").tag_name
          } catch (e) {
            console.error(e)
          }
          data[field.key] = version
        }
      },
    },
    window_tab: {
      LAST_TAB_CLOSE_ACTION: (field, data) => {
        if (utils.isBetaVersion) {
          const invalidOption = "blankPage"
          _disableOptions(field, invalidOption)
          if (data[field.key] === invalidOption) {
            data[field.key] = "reconfirm"
          }
        }
      },
    },
    read_only: {
      REMAIN_AVAILABLE_MENU_KEY: (field) => {
        if (!field.options) {
          const toOptions = item => {
            const key = item.dataset.key
            if (!key) return
            const hint = item.classList.contains("menu-style-btn")
              ? item.getAttribute("ty-hint")?.split("\t")[0]
              : item.querySelector(`[data-lg="Menu"]`)?.textContent.trim()
            return [key, hint || key]
          }
          const allItems = document.querySelectorAll(".context-menu:not(.ext-context-menu) [data-key]")
          field.options = Object.fromEntries([...allItems].map(toOptions).filter(Boolean))
        }
      },
    },
    fence_enhance: {
      ENABLE_INDENT: (field, data) => {
        if (utils.isBetaVersion) _disableSwitch(field, data)
      },
      PRELOAD_ALL_FENCES: (field, data) => {
        if (!Object.hasOwn(File, "loadFile")) _disableSwitch(field, data)
      },
    },
    blur: {
      ENABLE: (field, data) => {
        if (!utils.supportHasSelector) _disableSwitch(field, data)
      },
    },
    export_enhance: {
      ENABLE: (field, data) => {
        if (!utils.exportHelper.isAsync) _disableSwitch(field, data)
      },
    },
    html_editor: {
      ENABLE: (field, data) => {
        if (!Object.hasOwn(File, "readContentFrom")) _disableSwitch(field, data)
      },
    },
    sidebar_enhance: {
      DISPLAY_NON_MARKDOWN_FILES: (field, data) => {
        if (!File.SupportedFiles) _disableSwitch(field, data)
      },
      OUTLINE_FOLD_STATE: (field) => {
        if (!Object.hasOwn(File.option, "canCollapseOutlinePanel")) {
          _disableControl(field)
        } else if (!File.option.canCollapseOutlinePanel) {
          const text = i18n._t("sidebar_enhance", "$tooltip.canCollapseOutlinePanel")
          const tooltip = { action: "togglePreferencePanel", icon: "fa fa-gear", text }
          _disableControl(field, tooltip)
        } else {
          _enableControl(field, true)
        }
      },
    },
    markmap: {
      AUTO_COLLAPSE_PARAGRAPH_ON_FOLD: (field, data) => {
        if (!utils.getPlugin("collapse_paragraph")) {
          _disableSwitch(field, data, i18n._t("markmap", "$tooltip.experimental"))
        } else {
          _enableControl(field)
        }
      },
    },
    right_click_menu: {
      MENUS: (field) => {
        const subField = field.nestedBoxes.find(box => box.fields.some(field => field.key === "LIST"))?.fields[0]
        if (!subField?.options) {
          const allPlugins = Object.fromEntries(
            Object.entries(utils.getAllSettings()).map(([name, p]) => {
              const pluginName = p.NAME || i18n._t(name, "pluginName")
              return [name, pluginName]
            }),
          )
          allPlugins["---"] = "--- DIVIDER ---"
          subField.options = allPlugins
        }
      },
      SHOW_PLUGIN_HOTKEY: (field, data) => {
        if (!document.querySelector(".ty-menu-shortcut")) _disableSwitch(field, data)
      },
    },
    preferences: {
      DEFAULT_MENU: (field) => {
        if (!field.options) {
          field.options = { __LAST__: i18n.t("lastUsed"), ...plugin._getAllPlugins() }
        }
      },
      HIDE_MENUS: (field) => {
        if (!field.options) {
          field.options = plugin._getAllPlugins()
          _disableOptions(field, "global", "preferences")
        }
      },
    },
    markdownlint: {
      RULE_CONFIG: (field, data, box) => {
        if (utils.getPlugin("markdownlint")) {
          box.title = undefined
          box.fields[0] = { type: "action", key: "invokeMarkdownlintSettings", tooltip: box.tooltip, label: i18n._t("markdownlint", "$label.invokeMarkdownlintSettings") }
        }
      },
    },
  }
}
