class StaticMarkersPlugin extends BasePlugin {
  enabled = this.config.STATIC_DEFAULT
  STATIC_EFFECT = `display: inline !important; opacity: inherit !important;`
  SELECTORS = {
    strong: `.md-pair-s[md-inline="strong"] .md-meta`,
    em: `.md-pair-s[md-inline="em"] .md-meta`,
    del: `.md-pair-s[md-inline="del"] .md-meta`,
    underline: `.md-pair-s[md-inline="underline"] .md-meta`,
    highlight: `.md-pair-s[md-inline="highlight"] .md-meta`,
    superscript: `.md-pair-s[md-inline="superscript"] .md-meta`,
    subscript: `.md-pair-s[md-inline="subscript"] .md-meta`,
    code: `.md-pair-s[md-inline="code"] .md-meta`,
    inlineMath: `.md-inline-math[md-inline="inline_math"] .md-meta`,
    image: `.md-image.md-img-loaded[md-inline="image"] .md-meta`,
    // errorImage: `.md-image.md-img-error[md-inline="image"] .md-meta`,
    link: `.md-link[md-inline="link"] .md-meta, .md-link[md-inline="link"] .md-content`,
    emoji: `.md-emoji[md-inline="emoji"] .md-meta`,
    footnote: `.md-footnote[md-inline="footnote"] .md-meta`,
    inlineHTML: `.md-html-inline[md-inline="html_inline"] .md-meta`,
  }

  style = () => {
    if (!this.enabled) return ""
    const sel = this.config.STATIC_MARKERS.map(marker => this.SELECTORS[marker]).filter(Boolean).join(", ")
    return sel ? `${sel} { ${this.STATIC_EFFECT} }` : ""
  }

  hotkey = () => [{ hotkey: this.config.HOTKEY, callback: this.call }]

  getDynamicActions = () => {
    const general = { act_value: "toggle_state", act_state: this.enabled, act_name: this.i18n.t("act.toggle_state") }
    const specific = Object.keys(this.SELECTORS).map(s => ({
      act_value: s,
      act_name: this.i18n.t(`$option.STATIC_MARKERS.${s}`),
      act_state: this.config.STATIC_MARKERS.includes(s),
    }))
    return this.enabled ? [general, ...specific] : [general]
  }

  call = async (action, meta) => {
    let toSave
    if (action === "toggle_state") {
      this.enabled = !this.enabled
      toSave = { STATIC_DEFAULT: this.enabled }
    } else {
      const markers = new Set(this.config.STATIC_MARKERS)
      markers.has(action) ? markers.delete(action) : markers.add(action)
      this.config.STATIC_MARKERS = [...markers]
      toSave = { STATIC_MARKERS: this.config.STATIC_MARKERS }
    }
    await this.utils.settings.save(this.fixedName, toSave)

    this.utils.replaceStyle(this.fixedName, this.style())
  }
}

module.exports = {
  plugin: StaticMarkersPlugin,
}
