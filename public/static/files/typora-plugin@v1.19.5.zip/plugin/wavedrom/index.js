/**
 * Wavedrom's API requires an element ID string in the 'prefix+index' format,
 * but it separates the numeric index and string prefix into distinct arguments
 * rather than accepting the full ID as a single string representing a DOM element:
 *   const wavedrom = require('wavedrom');
 *   const div = document.createElement('div');
 *   div.id = 'a0';
 *   document.body.appendChild(div);
 *   const notFirstSignal = false;
 *   wavedrom.renderWaveForm(0, { signal:[] }, 'a', notFirstSignal);  // Index (0) and prefix ('a') are passed separately
 *
 * The rationale behind this design, as explained by the author, is:
 *   When having multiple diagrams on the same page, the id === 'a0' SVG has special properties.
 *   It holds a stash of building blocks (wave bricks), CSS attributes, and who knows what else...
 *   So, when the second diagram comes to the page, it inherits all this treasure, and thus weighs less.
 * See: https://github.com/wavedrom/wavedrom/issues/116
 *
 * This legacy approach presents challenges in environments like Typora, where charts are frequently deleted and re-rendered, hindering reuse.
 *   For instance, if only one chart exists on the page and the user modifies it, the existing instance needs to be removed and recreated.
 *     In this scenario, setting `notFirstSignal` to `true` will result in an error.
 *   Similarly, Typora's frequent re-rendering of all charts, involving deletion and recreation, leads to issues.
 *     Regardless of the number of diagrams, setting `notFirstSignal` to `true` will cause an error.
 *   Therefore, `notFirstSignal = false` is necessary to ensure correct rendering.
 *
 * These examples highlight that Wavedrom is primarily designed for static pages and exhibits limited support for single-page applications (SPAs).
 *   Wavedrom lacks automatic event listener removal and doesn't provide a dedicated removal interface, potentially leading to memory leaks.
 *   Consequently, in Typora, functions that create event listeners (e.g., `wavedrom.processAll`) should be avoided.
 *
 * Wavedrom's documentation is incomplete; source code inspection is often required.
 */
class WavedromPlugin extends BasePlugin {
  Wavedrom = null
  skins = {}
  PREFIX = "WaveDrom_Display_"
  evalFn = this.config.SAFE_MODE ? this.utils.safeEval : this.utils.unsafeEval

  prepare = async () => {
    const { FsExtra, Path } = this.utils.Package
    try {
      const folder = this.utils.resolvePluginPath(this.config.SKIN_FOLDER)
      const modules = await FsExtra.readdir(folder)
      this.skins = Object.fromEntries(
        modules
          .map(file => this.utils.resolvePluginPath(folder, file))
          .map(path => [Path.parse(path).name, path]),
      )
    } catch (err) {
      console.error(err)
    }
  }

  hotkey = () => [{ hotkey: this.config.HOTKEY, callback: this.call }]

  call = () => this.utils.insertBlockCode(null, this.config.LANGUAGE, this.config.TEMPLATE)

  process = () => {
    let idx = 0
    const parser = this.utils.thirdPartyDiagramParser
    parser.register({
      lang: this.config.LANGUAGE,
      mappingLang: "javascript",
      destroyWhenUpdate: false,
      interactiveMode: this.config.INTERACTIVE_MODE,
      metaConfigSchema: {
        ...parser.helpers.styleMetaConfigSchema.wrapDefaultStyle({
          height: this.config.DEFAULT_FENCE_HEIGHT,
          backgroundColor: this.config.DEFAULT_FENCE_BACKGROUND_COLOR,
        }),
        align: { type: "string", enum: ["left", "center", "right"], valueAliases: { l: "left", c: "center", r: "right" }, default: this.config.CHART_ALIGN },
        skin: { type: "string", enum: ["default", ...Object.keys(this.skins)], default: "default" },
        hscale: { type: "number", default: 1 },
      },
      checkSelector: ".plugin-wavedrom-content",
      wrapElement: () => `<div class="plugin-wavedrom-content" id="${this.PREFIX + ++idx}"></div>`,
      lazyLoadFunc: this.lazyLoad,
      beforeRenderFunc: null,
      renderStyleGetter: parser.helpers.renderStyle.wrapMeta(meta => ({ display: "flex", justifyContent: meta.align })),
      createFunc: this.create,
      updateFunc: null,
      destroyFunc: null,
      beforeExportToNative: null,
      beforeExportToHTML: null,
      exportStyleGetter: parser.helpers.exportStyle.svg,
      versionGetter: this.getVersion,
    })
  }

  create = ($wrap, content, meta) => {
    const index = parseInt($wrap.attr("id").slice(this.PREFIX.length))
    const waveJson = Object.assign({ config: { skin: meta.skin, hscale: meta.hscale } }, this.evalFn(content))
    const notFirstSignal = false
    this.Wavedrom.renderWaveForm(index, waveJson, this.PREFIX, notFirstSignal)
  }

  getVersion = () => this.Wavedrom?.version

  lazyLoad = async () => {
    this.Wavedrom = require("./wavedrom.min.js")
    const skins = Object.values(this.skins).map(require)
    window.WaveSkin = Object.assign(this.Wavedrom.waveSkin, ...skins)  // renderWaveForm() will use window.WaveSkin
  }
}

module.exports = {
  plugin: WavedromPlugin,
}
